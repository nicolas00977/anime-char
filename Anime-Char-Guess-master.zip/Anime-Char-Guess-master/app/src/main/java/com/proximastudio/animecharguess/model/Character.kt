package com.proximastudio.animecharguess.model

data class Character (
    val id : Int,
    val name : String,
    val series : String,
    val artist : String,
    val pict : String
)